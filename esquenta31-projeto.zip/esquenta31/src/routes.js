import { Router } from 'express';
import multer from 'multer';
import sharp from 'sharp';
import path from 'node:path';
import fs from 'node:fs';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { db } from './db.js';
import { requireAdmin } from './middleware.js';

const router = Router();
const uploadDir = path.resolve(process.env.UPLOAD_DIR || './public/uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({
  storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req,file,cb) => cb(null, ['image/jpeg','image/png','image/webp'].includes(file.mimetype))
});
const productSchema = z.object({
  name: z.string().trim().min(1).max(100), description: z.string().max(1000).optional().default(''),
  price: z.coerce.number().min(0), promo_price: z.union([z.coerce.number().min(0), z.literal(''), z.null()]).optional(),
  category_id: z.coerce.number().int().positive(), available: z.preprocess(v => v === true || v === 'true' || v === 1 || v === '1', z.boolean()).optional().default(true),
  featured: z.preprocess(v => v === true || v === 'true' || v === 1 || v === '1', z.boolean()).optional().default(false)
});
const categorySchema = z.object({
  name: z.string().trim().min(1).max(60), description: z.string().max(300).optional().default(''),
  sort_order: z.coerce.number().int().default(0), active: z.preprocess(v => v === true || v === 'true' || v === 1 || v === '1', z.boolean()).optional().default(true)
});
const settingKeys = ['name','tagline','description','phone','address','instagram','hours','logo','banner'];
const getSettings = () => Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(x=>[x.key,x.value]));
const productSelect = `SELECT p.*, c.name category_name FROM products p JOIN categories c ON c.id=p.category_id`;
router.get('/public/menu', (_req,res) => {
  const settings = getSettings();
  const categories = db.prepare('SELECT * FROM categories WHERE active=1 ORDER BY sort_order,name').all();
  const products = db.prepare(`${productSelect} WHERE p.available=1 AND c.active=1 ORDER BY p.featured DESC,p.name`).all();
  res.json({ settings, categories, products });
});
router.post('/auth/login', (req,res) => {
  const { email, password } = req.body || {};
  const admin = db.prepare('SELECT * FROM admins WHERE email=?').get(String(email||'').trim().toLowerCase());
  if (!admin || !bcrypt.compareSync(String(password||''), admin.password_hash)) return res.status(401).json({error:'E-mail ou senha inválidos.'});
  req.session.adminId = admin.id;
  req.session.adminName = admin.name;
  res.json({ id:admin.id, name:admin.name, email:admin.email });
});
router.post('/auth/logout', (req,res) => req.session.destroy(()=>res.json({ok:true})));
router.get('/auth/me', requireAdmin, (req,res)=>res.json({id:req.session.adminId,name:req.session.adminName}));
router.use('/admin', requireAdmin);

router.get('/admin/summary', (_req,res)=>{
  const products=db.prepare('SELECT COUNT(*) total, SUM(available=1) active, SUM(available=0) unavailable FROM products').get();
  const categories=db.prepare('SELECT COUNT(*) total FROM categories').get().total;
  res.json({products:products.total||0,active:products.active||0,unavailable:products.unavailable||0,categories});
});
router.get('/admin/products', (_req,res)=>res.json(db.prepare(`${productSelect} ORDER BY p.created_at DESC`).all()));
router.post('/admin/products', upload.single('image'), async (req,res)=>{
  const parsed=productSchema.safeParse(req.body); if(!parsed.success) return res.status(400).json({error:parsed.error.issues[0].message});
  const d=parsed.data;
  if(!db.prepare('SELECT id FROM categories WHERE id=?').get(d.category_id)) return res.status(400).json({error:'Categoria inválida.'});
  let image=''; if(req.file) image=await saveImage(req.file.buffer);
  const info=db.prepare(`INSERT INTO products(name,description,price,promo_price,image,category_id,available,featured) VALUES(?,?,?,?,?,?,?,?)`)
    .run(d.name,d.description,d.price,d.promo_price===''||d.promo_price==null?null:d.promo_price,image,d.category_id,+d.available,+d.featured);
  res.status(201).json({id:info.lastInsertRowid});
});
router.put('/admin/products/:id', upload.single('image'), async (req,res)=>{
  const parsed=productSchema.safeParse(req.body); if(!parsed.success) return res.status(400).json({error:parsed.error.issues[0].message});
  const old=db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id); if(!old) return res.status(404).json({error:'Produto não encontrado.'});
  const d=parsed.data; let image=old.image;
  if(req.file) { image=await saveImage(req.file.buffer); removeImage(old.image); }
  db.prepare(`UPDATE products SET name=?,description=?,price=?,promo_price=?,image=?,category_id=?,available=?,featured=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .run(d.name,d.description,d.price,d.promo_price===''||d.promo_price==null?null:d.promo_price,image,d.category_id,+d.available,+d.featured,req.params.id);
  res.json({ok:true});
});
router.delete('/admin/products/:id', (req,res)=>{
  const item=db.prepare('SELECT image FROM products WHERE id=?').get(req.params.id); if(!item) return res.status(404).json({error:'Produto não encontrado.'});
  db.prepare('DELETE FROM products WHERE id=?').run(req.params.id); removeImage(item.image); res.json({ok:true});
});
router.get('/admin/categories', (_req,res)=>res.json(db.prepare('SELECT * FROM categories ORDER BY sort_order,name').all()));
router.post('/admin/categories', (req,res)=>{
  const p=categorySchema.safeParse(req.body); if(!p.success)return res.status(400).json({error:p.error.issues[0].message});
  const d=p.data; const info=db.prepare('INSERT INTO categories(name,description,sort_order,active) VALUES(?,?,?,?)').run(d.name,d.description,d.sort_order,+d.active);
  res.status(201).json({id:info.lastInsertRowid});
});
router.put('/admin/categories/:id', (req,res)=>{
  const p=categorySchema.safeParse(req.body); if(!p.success)return res.status(400).json({error:p.error.issues[0].message});
  const d=p.data; const info=db.prepare('UPDATE categories SET name=?,description=?,sort_order=?,active=? WHERE id=?').run(d.name,d.description,d.sort_order,+d.active,req.params.id);
  if(!info.changes)return res.status(404).json({error:'Categoria não encontrada.'}); res.json({ok:true});
});
router.delete('/admin/categories/:id', (req,res)=>{
  const count=db.prepare('SELECT COUNT(*) n FROM products WHERE category_id=?').get(req.params.id).n;
  if(count)return res.status(409).json({error:'Esta categoria possui produtos. Mova ou remova os produtos antes de excluir.'});
  db.prepare('DELETE FROM categories WHERE id=?').run(req.params.id); res.json({ok:true});
});
router.get('/admin/settings', (_req,res)=>res.json(getSettings()));
router.put('/admin/settings', (req,res)=>{
  const up=db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  for(const key of settingKeys) if(req.body[key]!==undefined) up.run(key,String(req.body[key]).slice(0,2000));
  res.json(getSettings());
});
router.post('/admin/settings/image', upload.single('image'), async (req,res)=>{
  if(!req.file)return res.status(400).json({error:'Selecione uma imagem válida.'});
  const url=await saveImage(req.file.buffer); res.json({url});
});
async function saveImage(buffer) {
  const name=`${Date.now()}-${Math.random().toString(36).slice(2,10)}.webp`;
  await sharp(buffer).rotate().resize({width:1400,height:1400,fit:'inside',withoutEnlargement:true}).webp({quality:82}).toFile(path.join(uploadDir,name));
  return `/uploads/${name}`;
}
function removeImage(url) {
  if(!url || !url.startsWith('/uploads/'))return;
  const target=path.join(uploadDir,path.basename(url));
  if(fs.existsSync(target))fs.unlinkSync(target);
}
export default router;
