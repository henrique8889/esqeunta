import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import SQLiteStoreFactory from 'connect-sqlite3';
import helmet from 'helmet';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { db, initialize } from './src/db.js';
import api from './src/routes.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataDir = path.resolve('./data');
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(path.resolve(process.env.UPLOAD_DIR || './public/uploads'), { recursive: true });
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error('Defina SESSION_SECRET com pelo menos 32 caracteres no .env');
  process.exit(1);
}
initialize();
const SQLiteStore = SQLiteStoreFactory(session);
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: dataDir }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 8 }
}));
app.use('/uploads', express.static(path.resolve(process.env.UPLOAD_DIR || './public/uploads'), { maxAge: '7d', immutable: true }));
app.use('/api', api);
app.use('/assets', express.static(path.join(__dirname, 'public/assets')));
app.get('/', (_req, res) => res.redirect('/cardapio'));
app.get('/cardapio', (_req, res) => res.sendFile(path.join(__dirname, 'public/cardapio.html')));
app.get('/admin', (_req, res) => res.sendFile(path.join(__dirname, 'public/admin.html')));
app.get('/admin/login', (_req, res) => res.sendFile(path.join(__dirname, 'public/login.html')));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Erro interno do servidor.' });
});
app.listen(PORT, () => console.log(`ESQUENTA 31 disponível em http://localhost:${PORT}`));
