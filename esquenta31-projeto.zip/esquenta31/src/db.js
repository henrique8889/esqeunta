import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
const file = path.resolve(process.env.DATABASE_FILE || './data/esquenta31.sqlite');
fs.mkdirSync(path.dirname(file), { recursive: true });
export const db = new Database(file);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
export function initialize() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
      sort_order INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
      price REAL NOT NULL CHECK(price >= 0), promo_price REAL, image TEXT DEFAULT '',
      category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
      available INTEGER NOT NULL DEFAULT 1, featured INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY, value TEXT NOT NULL
    );
  `);
  const defaults = {
    name: 'ESQUENTA 31', tagline: 'Seu momento começa aqui.', description: 'Confira nosso cardápio e escolha seus favoritos.',
    phone: '', address: '', instagram: '', hours: '', logo: '', banner: ''
  };
  const insert = db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)');
  for (const [k,v] of Object.entries(defaults)) insert.run(k,v);
  if (db.prepare('SELECT COUNT(*) n FROM categories').get().n === 0) {
    const add = db.prepare('INSERT INTO categories(name,sort_order) VALUES (?,?)');
    ['Porções','Bebidas','Combos','Lanches','Sobremesas'].forEach((n,i)=>add.run(n,i));
  }
}
