# ESQUENTA 31 — Cardápio virtual

Aplicação full-stack com cardápio público, painel administrativo, autenticação, SQLite persistente e upload otimizado de imagens.

## Requisitos
- Node.js 20 ou superior
- npm

## Instalação
```bash
npm install
cp .env.example .env
```
Edite `.env` e substitua `SESSION_SECRET` por uma chave longa e aleatória.

## Criar o primeiro administrador
```bash
npm run admin:create
```
O script solicita nome, e-mail e senha no terminal. Não existe senha padrão.

## Executar
```bash
npm run dev
```
Acesse:
- Cardápio: http://localhost:3000/cardapio
- Painel: http://localhost:3000/admin
- Login: http://localhost:3000/admin/login

## Funcionalidades
- CRUD de produtos e categorias.
- Disponibilidade, destaque e preço promocional.
- Upload de imagens com conversão para WebP.
- Configurações do estabelecimento.
- Dashboard com indicadores.
- Sessão administrativa armazenada em SQLite.
- API pública somente de leitura para o cardápio.
- Proteção das rotas administrativas e validação no servidor.

## Banco e arquivos
O banco SQLite é criado automaticamente em `data/esquenta31.sqlite`.
Imagens ficam em `public/uploads`. Faça backup dos dois locais.

## Publicação
Use um servidor Node.js com disco persistente (VPS ou serviço que ofereça volume persistente). Configure:
- `NODE_ENV=production`
- `SESSION_SECRET` forte e exclusivo
- `BASE_URL` com o domínio HTTPS definitivo
- `DATABASE_FILE` em volume persistente
- `UPLOAD_DIR` em volume persistente

Coloque a aplicação atrás de um proxy HTTPS (por exemplo, Nginx). Em produção, configure o proxy para encaminhar `X-Forwarded-Proto`, e habilite HTTPS. O cookie de sessão passa a ser `Secure` em produção.

**Importante:** hospedagens serverless com filesystem efêmero não são adequadas para este armazenamento local. Para múltiplas instâncias, migre SQLite e uploads para serviços gerenciados (PostgreSQL + armazenamento de objetos).

## QR Code
Depois de publicar o site, gere um QR Code apontando para `https://SEU-DOMINIO/cardapio`. O QR Code é estático; se o domínio permanecer o mesmo, ele continuará funcionando mesmo quando os produtos mudarem.

## Segurança e operação
- Crie administrador com senha forte e não compartilhe credenciais.
- Não exponha `.env`, `data/` nem arquivos de backup.
- Faça backup frequente do banco e da pasta de uploads.
- Para trocar a senha, redefina-a no banco por um procedimento administrativo seguro; não edite o hash manualmente.
