import 'dotenv/config';
import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import bcrypt from 'bcryptjs';
import { initialize, db } from '../src/db.js';
initialize();
const rl=readline.createInterface({input,output});
try {
  const name=(await rl.question('Nome do administrador: ')).trim();
  const email=(await rl.question('E-mail: ')).trim().toLowerCase();
  const password=await rl.question('Senha (mínimo 10 caracteres): ');
  if(!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length<10) throw new Error('Dados inválidos. Informe nome, e-mail válido e senha com pelo menos 10 caracteres.');
  const hash=await bcrypt.hash(password,12);
  db.prepare('INSERT INTO admins(name,email,password_hash) VALUES(?,?,?)').run(name,email,hash);
  console.log('Administrador criado com sucesso.');
} catch(e) { console.error(e.message); process.exitCode=1; }
finally { rl.close(); db.close(); }
